#from __future__ import annotations
#from typing import TYPE_CHECKING
#if TYPE_CHECKING:
#  from _typeshed import Self
#from _typeshed import Self
#import sys
import pygame
from pygame import draw
from pygame.constants import MOUSEBUTTONDOWN
from pygame.locals import QUIT
import random

#Battle confliction circular dependencies <============ BUG Importing battle.py
#import battle

#import check
import statPlacement
#import rooms

pygame.init()
window = pygame.display.set_mode((1000, 1000))
font = pygame.font.Font('freesansbold.ttf', 20)
font2 = pygame.font.Font('freesansbold.ttf', 32)
stats = statPlacement.Stats()

#variables
potions = 0


#confliction with roll being called in battle.py and item.py.
#idk how to fix it but the AI said to create a roll.py file to store the roll
#if otherwise then to import the roll from the battle.py file
#my bad I havent seen this bug before and Id rather keep my changes superficial
#So I dont break the program
class roll:

  def dice(self, stat):
    dice = random.randint(1, 20)
    dice = dice + stat
    if dice > 20:
      dice = 20
    return dice

  def ItemRoll(self):

    dice = random.randint(1, 5)
    dice = dice
    if dice == 1:
      textpotion = "You aquired a potion"
      textpotion1 = font.render(textpotion, True, (255, 255, 255))
      window.blit(textpotion1, (150, 605))
      items.PotionsFind(self)
    elif dice == 2:
      textweapon = "You aquired a legendary scar"
      textweapon1 = font.render(textweapon, True, (255, 255, 255))
      window.blit(textweapon1, (150, 605))
      items.WeaponsFind(self)
    elif dice == 3:
      textbook = "You aquired a book of spells"
      textbook1 = font.render(textbook, True, (255, 255, 255))
      window.blit(textbook1, (150, 605))
      items.BookFind(self)
    elif dice == 4:
      textRizz = "You aquired a Rizz Gun"
      textRizz1 = font.render(textRizz, True, (255, 255, 255))
      window.blit(textRizz1, (150, 605))
      items.RizzFind(self)
    elif dice == 5:
      textarmor = "You aquired a body pillow"
      textarmor1 = font.render(textarmor, True, (255, 255, 255))
      window.blit(textarmor1, (150, 605))
      items.ArmorFind(self)
    return dice


class items:

  def PotionsUse(self, potions):
    #Slurp Juice
    global strength, dexterity, health, intel, wisdom, chrisma
    strength, dexterity, health, intel, wisdom, chrisma = stats.StatsCall()

    #check for potion
    if potions > 0:
      #use potion
      health = +20
      if health > hpMax:
        health = hpMaX

    #Return health
    return health
    #Find Potions add Potions to inventory
  def PotionsFind(self):
    print('Potion acquired')
    return potions

  def WeaponsFind(self):
    #Legendary Scar
    global strength, dexterity, health, intel, wisdom, chrisma
    strength, dexterity, health, intel, wisdom, chrisma = stats.StatsCall()
    strength = +2
    return strength

  def BookFind(self):
    #War Hammer Codex
    global strength, dexterity, health, intel, wisdom, chrisma
    strength, dexterity, health, intel, wisdom, chrisma = stats.StatsCall()
    intel = +2
    return intel

  def RizzFind(self):
    #Rizz 101
    global strength, dexterity, health, intel, wisdom, chrisma
    strength, dexterity, health, intel, wisdom, chrisma = stats.StatsCall()
    chrisma = +2
    return chrisma

  def ArmorFind(self):
    #Waifu Body pillows
    global strength, dexterity, health, intel, wisdom, chrisma
    strength, dexterity, health, intel, wisdom, chrisma = stats.StatsCall()
    dexterity = +2
    return dexterity
