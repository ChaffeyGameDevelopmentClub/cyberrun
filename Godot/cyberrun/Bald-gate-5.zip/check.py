import pygame
from pygame.constants import MOUSEBUTTONDOWN
import statPlacement

pygame.init()
font = pygame.font.Font('freesansbold.ttf', 20)
font2 = pygame.font.Font('freesansbold.ttf', 32)
window = pygame.display.set_mode((1000, 1000))


class Check:

  def checkContinue(self):
    #draw continue button
    print("continue")
    buttonCon = pygame.Rect(5, 600, 115, 35)
    textButtonCon = font.render("Continue", True, (255, 255, 255))
    pygame.draw.rect(window, (40, 212, 239), buttonCon)
    window.blit(textButtonCon, (15, 605))
    #update
    pygame.display.update()
    run = True
    while run:
      for event in pygame.event.get():
        if event.type == MOUSEBUTTONDOWN:
          mousePos = pygame.mouse.get_pos()
          #check for click
          if buttonCon.collidepoint(mousePos):
            run = False

      pygame.display.update()

    pygame.display.update()

  def checkFind(self):
    #see what they found
    global strength, dexterity, health, intel, wisdom, chrisma
    strength, dexterity, health, intel, wisdom, chrisma = stats.StatsCall()
    if wisdom >= 7:
      print("You found an Item")
    elif wisdom <= 5:
      print("Too Bad")
