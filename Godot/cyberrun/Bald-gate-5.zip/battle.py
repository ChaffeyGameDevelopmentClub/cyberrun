#Battle scripts

import pygame
from pygame.constants import MOUSEBUTTONDOWN

#Second Dependieces <============ BUG/ Importing items.py
import items


import statPlacement
import check
import random

pygame.init()
font = pygame.font.Font('freesansbold.ttf', 20)
font2 = pygame.font.Font('freesansbold.ttf', 32)
window = pygame.display.set_mode((1000, 1000))

check1 = check.Check()
stats = statPlacement.Stats()
roll = items.roll()


#Enemy attack
def EnBattle(self, pHP, pSpeed, enHp, enSpeed, enAttack):
  #Attacks
  check = roll.dice(enAttack)
  if check >= pSpeed:
    #hit
    pHP = pHP - enAttack
    hitStr = "The enemy hit you for " + str(enAttack) + " Physical damage!"
    text = font.render(hitStr, True, (255, 255, 255))
    window.blit(text, (150, 605))
    return pHP
    #update enemy health

  else:
    #miss
    hitStr = "Enemy's attack missed "
    text = font.render(hitStr, True, (255, 255, 255))
    window.blit(text, (150, 605))
    return pHP


#Battle.Attack(streng,int,fdsajkflj)
class playerUpdate:

  def draw_health_bar(self, surface, x, y, health, maxHp):
    if health < 0:
      health = 0
    BAR_LENGTH = 300
    BAR_HEIGHT = 50
    fill = (health / maxHp) * BAR_LENGTH
    outline_rect = pygame.Rect(x, y, BAR_LENGTH, BAR_HEIGHT)
    fill_rect = pygame.Rect(x, y, fill, BAR_HEIGHT)
    pygame.draw.rect(surface, (255, 0, 0), fill_rect)
    pygame.draw.rect(surface, (0, 255, 0), outline_rect, 2)

  def draw_Hp_Text(self, surface, x, y, health, maxHp):
    if health < 0:
      health = 0
    healthString = str(health) + "/" + str(maxHp) + "HP"
    healthText = font.render(healthString, True, (255, 255, 255))
    window.blit(healthText, (x, y))


class Battle:

  def Attack(self, pHP, playerStr, playerInt, playerChr, playerDex, enHp,
             enSpeed, enAttack, enType):
    #Attacks
    pygame.draw.rect(window, (0, 0, 0), (0, 600, 1000, 1000))
    text = font.render(
        "You choose to attack. Please pick which attack you want to use", True,
        (255, 255, 255))
    window.blit(text, (150, 605))
    #Draw buttons
    button1 = pygame.Rect(100, 650, 200, 50)
    button2 = pygame.Rect(400, 650, 200, 50)
    button3 = pygame.Rect(700, 650, 200, 50)
    textButton1 = font.render("Physical Attack", True, (255, 255, 255))
    textButton2 = font.render("Magic Attack", True, (255, 255, 255))
    textButton3 = font.render("Special Attack", True, (255, 255, 255))
    pygame.draw.rect(window, (197, 39, 39), button1)
    pygame.draw.rect(window, (84, 216, 251), button2)
    pygame.draw.rect(window, (208, 87, 214), button3)
    window.blit(textButton1, (125, 665))
    window.blit(textButton2, (435, 665))
    window.blit(textButton3, (725, 665))
    #check for click
    run = True
    while run:
      for event in pygame.event.get():
        if event.type == MOUSEBUTTONDOWN:
          mousePos = pygame.mouse.get_pos()
          #check for click

          if button1.collidepoint(mousePos):
            #physical attack

            #cover previous text
            pygame.draw.rect(window, (0, 0, 0), (0, 600, 1000, 100))
            #draw text
            #check if hit
            check = roll.dice(playerStr)
            if check >= enSpeed:
              #hit
              #check type
              if enType == "Magic":
                playerStr = playerStr * 1.5
              hitStr = "You hit the enemy for " + str(
                  playerStr) + " Physical damage!"
              text = font.render(hitStr, True, (255, 255, 255))
              window.blit(text, (150, 605))
              #update enemy health
              enHp = enHp - playerStr
            else:
              #miss
              hitStr = "Your attack missed. You lost " + str(enAttack) + " HP!"
              text = font.render(hitStr, True, (255, 255, 255))
              window.blit(text, (150, 605))
              #update player health
              pHP = pHP - enAttack
            #Emeny attack

            #check for continue
            #draw continue button

            buttonCon = pygame.Rect(5, 600, 115, 35)
            textButtonCon = font.render("Continue", True, (255, 255, 255))
            pygame.draw.rect(window, (40, 212, 239), buttonCon)
            window.blit(textButtonCon, (15, 605))
            pygame.display.update()
            #check for continue
            check1.checkContinue()
            run = False
            #cover screen
            pygame.draw.rect(window, (0, 0, 0), (0, 600, 1000, 100))
            #Enemy attack
            pHP = EnBattle(self, pHP, playerDex, enHp, enSpeed, enAttack)
            check1.checkContinue()

          if button2.collidepoint(mousePos):
            #Magic attack

            #cover previous text
            pygame.draw.rect(window, (0, 0, 0), (0, 600, 1000, 100))
            #draw text
            #check if hit
            check = roll.dice(playerStr)
            if check >= enSpeed:
              #hit
              #check type
              if enType == "Lust":
                playerStr = playerInt * 1.5
              hitStr = "You hit the enemy for " + str(
                  playerInt) + " Magic damage!"
              text = font.render(hitStr, True, (255, 255, 255))
              window.blit(text, (150, 605))
              #update enemy health
              enHp = enHp - playerInt
            else:
              #miss
              hitStr = "Your attack missed. You lost " + str(enAttack) + " HP!"
              text = font.render(hitStr, True, (255, 255, 255))
              window.blit(text, (150, 605))
              #update player health
              pHP = pHP - enAttack
            #check for continue
            #draw continue button

            buttonCon = pygame.Rect(5, 600, 115, 35)
            textButtonCon = font.render("Continue", True, (255, 255, 255))
            pygame.draw.rect(window, (40, 212, 239), buttonCon)
            window.blit(textButtonCon, (15, 605))
            pygame.display.update()
            #check for continue
            check1.checkContinue()
            run = False
            #cover screen
            pygame.draw.rect(window, (0, 0, 0), (0, 600, 1000, 100))
            #Enemy attack
            pHP = EnBattle(self, pHP, playerDex, enHp, enSpeed, enAttack)
            check1.checkContinue()

          if button3.collidepoint(mousePos):
            #Lust attack

            #cover previous text
            pygame.draw.rect(window, (0, 0, 0), (0, 600, 1000, 100))
            #draw text
            #check if hit
            check = roll.dice(playerChr)
            if check >= enSpeed:
              #hit
              #check type
              if enType == "Magic":
                playerStr = playerChr * 1.5
              hitStr = "You hit the enemy for " + str(
                  playerChr) + " Rizz damage!"
              text = font.render(hitStr, True, (255, 255, 255))
              window.blit(text, (150, 605))
              #update enemy health
              enHp = enHp - playerChr
            else:
              #miss
              hitStr = "Your attack missed. You lost " + str(enAttack) + " HP!"
              text = font.render(hitStr, True, (255, 255, 255))
              window.blit(text, (150, 605))
              #update player health
              pHP = pHP - enAttack
            #check for continue

            #draw continue button

            buttonCon = pygame.Rect(5, 600, 115, 35)
            textButtonCon = font.render("Continue", True, (255, 255, 255))
            pygame.draw.rect(window, (40, 212, 239), buttonCon)
            window.blit(textButtonCon, (15, 605))
            pygame.display.update()
            #check for continue
            check1.checkContinue()
            run = False
            #cover screen
            pygame.draw.rect(window, (0, 0, 0), (0, 600, 1000, 100))
            #Enemy attack
            pHP = EnBattle(self, pHP, playerDex, enHp, enSpeed, enAttack)
            check1.checkContinue()

      pygame.display.update()
    return enHp, pHP

  def Inventory(self, potions, Str, Dex, Con, Int, Wis, Chr):
    #statScreen/Use potoion
    pygame.draw.rect(window, (0, 0, 0), (0, 600, 1000, 1000))
    #display items/stats
    #strength, dexterity, Constitution, intel, wisdom, chrisma
    textStr = "Potions: " + str(potions)
    text = font.render(textStr, True, (255, 255, 255))
    textStr2 = "Str: " + str(Str)
    text2 = font.render(textStr2, True, (255, 255, 255))
    textStr3 = "Dex: " + str(Dex)
    text3 = font.render(textStr3, True, (255, 255, 255))
    textStr4 = "Con: " + str(Con)
    text4 = font.render(textStr4, True, (255, 255, 255))
    textStr5 = "Int: " + str(Int)
    text5 = font.render(textStr5, True, (255, 255, 255))
    textStr6 = "Wis: " + str(Wis)
    text6 = font.render(textStr6, True, (255, 255, 255))
    textStr7 = "Chr: " + str(Chr)
    text7 = font.render(textStr7, True, (255, 255, 255))

    #display stats
    window.blit(text, (150, 605))
    window.blit(text2, (275, 605))
    window.blit(text3, (275, 630))
    window.blit(text4, (275, 655))
    window.blit(text5, (375, 605))
    window.blit(text6, (375, 630))
    window.blit(text7, (375, 655))

    #draw continue button

    check1.checkContinue()
