import sys
import pygame
from pygame.constants import MOUSEBUTTONDOWN
from pygame.locals import QUIT
import random
#Variables for player stats
#Strength, Dexterity, Constitution, Intelligence, Wisdom, and Charisma
global font
strength = 3
dexterity = 3
health = 3
intel = 3
wisdom = 3
chrisma = 3
baldness = 3
hpMax = health
pygame.init()
font = pygame.font.Font('freesansbold.ttf', 20)
font2 = pygame.font.Font('freesansbold.ttf', 32)
window = pygame.display.set_mode((1000, 1000))
#defining buttons yes and no
textYes = font.render("1", True, (255,255,255))
textNo = font.render("2", True, (255,255,255))
buttonYes = pygame.Rect(25,150,100,50)
buttonNo = pygame.Rect(125,150,100,50)


#Class to place stats
class Questions:

  def Quest1(self):
    global strength, dexterity, health, intel, wisdom, chrisma, baldness
    pygame.draw.rect(window, (0,0,0), (0,0,1000,1000))
    #Ask questions to place stats
    #print("Would you rather go to the gym or the Library?")
    text1 = font.render("Would you rather go to the gym or the Library?", True, (255,255,255))
    #print("1. Gym 2. Library")
    text2 = font.render("1. Gym 2. Library", True, (255,255,255))
    #load mac's jealousy
    
    #draw text
    window.blit(text1, (25,25))
    window.blit(text2, (25,100))
    #draw buttons
    pygame.draw.rect(window,(255,0,0),buttonNo)
    pygame.draw.rect(window,(0,255,0),buttonYes)
    window.blit(textYes, (buttonYes.x + (buttonYes.width / 4), buttonYes.y + (buttonYes.height / 4)))
    window.blit(textNo, (buttonNo.x + (buttonNo.width / 4), buttonNo.y + (buttonNo.height / 4)))
    pygame.display.update()
    #Question 1
    q1 = True
    while q1:
      ans = 0
      for event in pygame.event.get():
        if event.type == MOUSEBUTTONDOWN:
          mousePos = pygame.mouse.get_pos()
          #check for click
          if buttonYes.collidepoint(mousePos):
            print("1")
            #show = True
            ans = "1"
          elif buttonNo.collidepoint(mousePos):
            print("2")
            #show = False
            ans = "2"
      
        if ans == "1":
          strength += 3
          dexterity += 2
          health += 3
          intel -= 1
          wisdom += 0
          chrisma += 2
          baldness += 0
          #Hide text
          pygame.draw.rect(window, (0,0,0), (0,0,1000,1000))
          q1 = False
          
        elif ans == "2":
          strength -= 3
          dexterity -= 1
          health += 1
          intel += 3
          wisdom += 3
          chrisma -= 1
          baldness += 0
          #Hide text
          pygame.draw.rect(window, (0,0,0), (0,0,1000,1000))
          q1 = False
    

  def Quest2(self):
    global strength, dexterity, health, intel, wisdom, chrisma, baldness
    #print("Would you rather eat a double krabby Patty or Cesars Salad?")
    #print("1. Double Krabby Patty 2. Cesars Salad")
    text1 = font.render("Would you rather eat a double krabby Patty or Cesars Salad?", True, (255,255,255))
    #print("1. Gym 2. Library")
    text2 = font.render("1. Double Krabby Patty 2. Cesars Salad", True, (255,255,255))
    #draw text
    window.blit(text1, (25,25))
    window.blit(text2, (25,100))
    #draw buttons
    pygame.draw.rect(window,(255,0,0),buttonNo)
    pygame.draw.rect(window,(0,255,0),buttonYes)
    window.blit(textYes, (buttonYes.x + (buttonYes.width / 4), buttonYes.y + (buttonYes.height / 4)))
    window.blit(textNo, (buttonNo.x + (buttonNo.width / 4), buttonNo.y + (buttonNo.height / 4)))
    pygame.display.update()
    q2 = True
    while q2:
      ans = 0
      for event in pygame.event.get():
        if event.type == MOUSEBUTTONDOWN:
          mousePos = pygame.mouse.get_pos()
          #check for click
          if buttonYes.collidepoint(mousePos):
            print("1")
            #show = True
            ans = "1"
          elif buttonNo.collidepoint(mousePos):
            print("2")
            #show = False
            ans = "2"
    
        if ans == "1":
          strength += 2
          dexterity -= 1
          health += 1
          intel -= 1
          wisdom += 3
          chrisma -= 1
          baldness += 2
          #Hide text
          pygame.draw.rect(window, (0,0,0), (0,0,1000,1000))
          q2 = False
        elif ans == "2":
          strength += 1
          dexterity += 3
          health += 2
          intel += 2
          wisdom -= 1
          chrisma -= 1
          #Hide text
          pygame.draw.rect(window, (0,0,0), (0,0,1000,1000))
          q2 = False
  
  def Quest3(self):
    global strength, dexterity, health, intel, wisdom, chrisma, baldness
    #print("Would you rather eat a double krabby Patty or Cesars Salad?")
    #print("1. Double Krabby Patty 2. Cesars Salad")
    text1 = font.render("Would you rather watch horror or romcom?", True, (255,255,255))
    #print("1. Gym 2. Library")
    text2 = font.render("1. Horror 2. Romcom", True, (255,255,255))
    #draw text
    window.blit(text1, (25,25))
    window.blit(text2, (25,100))
    #draw buttons
    pygame.draw.rect(window,(255,0,0),buttonNo)
    pygame.draw.rect(window,(0,255,0),buttonYes)
    window.blit(textYes, (buttonYes.x + (buttonYes.width / 4), buttonYes.y + (buttonYes.height / 4)))
    window.blit(textNo, (buttonNo.x + (buttonNo.width / 4), buttonNo.y + (buttonNo.height / 4)))
    pygame.display.update()
    q3 = True
    while q3:
      ans = 0
      for event in pygame.event.get():
        if event.type == MOUSEBUTTONDOWN:
          mousePos = pygame.mouse.get_pos()
          #check for click
          if buttonYes.collidepoint(mousePos):
            print("1")
            #show = True
            ans = "1"
          elif buttonNo.collidepoint(mousePos):
            print("2")
            #show = False
            ans = "2"

        if ans == "1":
          strength += 1
          dexterity += 3
          health -= 2
          intel -= 1
          wisdom += 3
          chrisma += 1
          baldness += 0
          q3 = False
          #Hide text
          pygame.draw.rect(window, (0,0,0), (0,0,1000,1000))
          q3 = False
        elif ans == "2":
          strength -= 2
          dexterity -= 1
          health += 2
          intel -= 1
          wisdom += 3
          chrisma += 3
          baldness += 0
          #Hide text
          pygame.draw.rect(window, (0,0,0), (0,0,1000,1000))
          q3 = False

  def Quest4(self):
    global strength, dexterity, health, intel, wisdom, chrisma, baldness
    #print("Would you rather eat a double krabby Patty or Cesars Salad?")
    #print("1. Double Krabby Patty 2. Cesars Salad")
    text1 = font.render("Flee or Fight?", True, (255,255,255))
    #print("1. Gym 2. Library")
    text2 = font.render("1. Flee 2. Fight", True, (255,255,255))
    #draw text
    window.blit(text1, (25,25))
    window.blit(text2, (25,100))
    #draw buttons
    pygame.draw.rect(window,(255,0,0),buttonNo)
    pygame.draw.rect(window,(0,255,0),buttonYes)
    window.blit(textYes, (buttonYes.x + (buttonYes.width / 4), buttonYes.y + (buttonYes.height / 4)))
    window.blit(textNo, (buttonNo.x + (buttonNo.width / 4), buttonNo.y + (buttonNo.height / 4)))
    pygame.display.update()
    q4 = True
    while q4:
      ans = 0
      for event in pygame.event.get():
        if event.type == MOUSEBUTTONDOWN:
          mousePos = pygame.mouse.get_pos()
          #check for click
          if buttonYes.collidepoint(mousePos):
            print("1")
            #show = True
            ans = "1"
          elif buttonNo.collidepoint(mousePos):
            print("2")
            #show = False
            ans = "2"

        if ans == "1":
          strength -= 2
          dexterity += 3
          health += 3
          intel += 1
          wisdom -= 3
          chrisma -= 1
            
          #Hide text
          pygame.draw.rect(window, (0,0,0), (0,0,1000,1000))
          q4 = False
        elif ans == "2":
          strength += 3
          dexterity += 1
          health += 3
          intel -= 2
          wisdom -= 3
          chrisma += 2
          baldness += 0
          #Hide text
          pygame.draw.rect(window, (0,0,0), (0,0,1000,1000))
          q4 = False

  def Quest5(self):
    global strength, dexterity, health, intel, wisdom, chrisma, baldness
    #Question 5
    text1 = font.render("Would you rather be a hero or a villian?", True, (255,255,255))
    #print("1. Gym 2. Library")
    text2 = font.render("1. Hero 2. Villan", True, (255,255,255))
    #draw text
    window.blit(text1, (25,25))
    window.blit(text2, (25,100))
    #draw buttons
    pygame.draw.rect(window,(255,0,0),buttonNo)
    pygame.draw.rect(window,(0,255,0),buttonYes)
    window.blit(textYes, (buttonYes.x + (buttonYes.width / 4), buttonYes.y + (buttonYes.height / 4)))
    window.blit(textNo, (buttonNo.x + (buttonNo.width / 4), buttonNo.y + (buttonNo.height / 4)))
    pygame.display.update()
    q5 = True
    while q5:
      ans = 0
      for event in pygame.event.get():
        if event.type == MOUSEBUTTONDOWN:
          mousePos = pygame.mouse.get_pos()
          #check for click
          if buttonYes.collidepoint(mousePos):
            print("1")
            #show = True
            ans = "1"
          elif buttonNo.collidepoint(mousePos):
            print("2")
            #show = False
            ans = "2"

        if ans == "1":
          strength += 2
          dexterity -= 1
          health += 1
          intel -= 1
          wisdom += 3
          chrisma -= 1
          baldness += 2
          #Hide text
          pygame.draw.rect(window, (0,0,0), (0,0,1000,1000))
          q5 = False
        elif ans == "2":
          strength += 1
          dexterity += 3
          health += 2
          intel += 2
          wisdom -= 1
          chrisma -= 1
          #Hide text
          pygame.draw.rect(window, (0,0,0), (0,0,1000,1000))
          q5 = False

  def Quest6(self):
    global strength, dexterity, health, intel, wisdom, chrisma, baldness
    #Benny question
    text1 = font.render("Would you go to Benny's and Mac's wedding?(No for hard mode)", True, (255,255,255))
    text2 = font.render("1.Yes 2.No", True, (255,255,255))
    #load image
    image = pygame.image.load("photos/Mac_and_benny.png")
    image = pygame.transform.scale(image, (600, 400))
    #draw text
    window.blit(text1, (25,25))
    window.blit(text2, (25,100))
    window.blit(image, (300,100))
    #draw buttons
    pygame.draw.rect(window,(255,0,0),buttonNo)
    pygame.draw.rect(window,(0,255,0),buttonYes)
    window.blit(textYes, (buttonYes.x + (buttonYes.width / 4), buttonYes.y + (buttonYes.height / 4)))
    window.blit(textNo, (buttonNo.x + (buttonNo.width / 4), buttonNo.y + (buttonNo.height / 4)))
    pygame.display.update()
    q6 = True
    while q6:
      ans = 0
      for event in pygame.event.get():
        if event.type == MOUSEBUTTONDOWN:
          mousePos = pygame.mouse.get_pos()
          #check for click
          if buttonYes.collidepoint(mousePos):
            print("1")
            #show = True
            ans = "1"
          elif buttonNo.collidepoint(mousePos):
            print("2")
            #show = False
            ans = "2"

      if ans == "1":
        strength += 0
        dexterity -= 0
        health += 0
        intel -= 0
        wisdom += 0
        chrisma -= 0
        baldness += 0
        #Hide text
        pygame.draw.rect(window, (0,0,0), (0,0,1000,1000))
        q6 = False
      elif ans == "2":
        strength += 0
        dexterity += 0
        health += 0
        intel += 0
        wisdom -= 0
        chrisma -= 0
        baldness += 50
        #Hide text
        pygame.draw.rect(window, (0,0,0), (0,0,1000,1000))
        q6 = False


#Class Stats
class Stats:

  def StatsCheck(self):
    #no - stats
    global strength, dexterity, health, intel, wisdom, chrisma, baldness
    #Strenght
    if(strength<0):
      strength = 0
    elif(strength>20):
      strength = 20
    #Dexterity
    if(dexterity<0):
      dexterity = 0
    elif(dexterity>20):
      dexterity = 20
    #health
    if(health<0):
      health = 0
    elif(health>20):
      health = 20
    #intel
    if(intel<0):
      intel = 0
    elif(intel>20):
      intel = 20
    #wisdom
    if(wisdom<0):
      wisdom = 0
    elif(wisdom>20):
      wisdom = 20
    #chrisma
    if(chrisma<0):
      chrisma = 0
    elif(chrisma>20):
      chrisma = 20
      

  def StatsCall(self):
    print("Stength: ", strength)
    print("Dexterity: ", dexterity)
    print("Constitution: ", health)
    print("Intellengence: ", intel)
    print("Wisodm: ", wisdom)
    print("Chrisma: ", chrisma)
    print("Null: ", baldness)
    return strength, dexterity, health, intel, wisdom, chrisma, hpMax

  def setMaxHp(self):
    global health
    hp = health*10
    return hp

  def statsDisplay(self):
    global strength, dexterity, health, intel, wisdom, chrisma, baldness
    #hide
    pygame.draw.rect(window, (0,0,0), (0,0,1000,1000))
    bald = False
    #Bald gate curse
    if baldness >= 50:
      strength = 3
      dexterity = 4
      health = 8
      intel = 3
      wisdom = 5
      chrisma = 0
      baldness = 50
      imageBenny = pygame.image.load("photos/bennyScary.jpg")
      image = pygame.transform.scale(imageBenny, (650, 300))
      text9 = font.render("Life went down hill after missing the wedding...(Hardmode Active)", True, (255,255,255))
      window.blit(text9,(300,100))
      window.blit(image, (300,150))
      
    text9 = 0
    #make text
    text1 = font.render("Player stats", True, (255,255,255))
    
    text2 = font.render("Strength:", True, (255,255,255))
    text2s = font.render(str(strength), True, (255,255,255))
    
    text3 = font.render("Dexterity:", True, (255,255,255))
    text3s = font.render(str(dexterity), True, (255,255,255))
    
    text4 = font.render("Constitution:", True, (255,255,255))
    text4s = font.render(str(health), True, (255,255,255))
    
    text5 = font.render("Intellengence:", True, (255,255,255))
    text5s = font.render(str(intel), True, (255,255,255))
    
    text6 = font.render("Wisdom:", True, (255,255,255))
    text6s = font.render(str(wisdom), True, (255,255,255))
    
    text7 = font.render("Chrisma:", True, (255,255,255))
    text7s = font.render(str(chrisma), True, (255,255,255))

    text8 = font.render("Null:", True, (255,255,255))
    text8s = font.render(str(baldness), True, (255,255,255))

    textStatsDisplay = font.render("Continue", True, (255,255,255))
    statsDisplayButton = pygame.Rect(25,450,150,50)
    
    
    
    #draw text
    window.blit(text1, (25,25))
    window.blit(text2, (25,100))
    window.blit(text3, (25,150))
    window.blit(text4, (25,200))
    window.blit(text5, (25,250))
    window.blit(text6, (25,300))
    window.blit(text7, (25,350))
    window.blit(text8, (25,400))
    window.blit(text2s, (200,100))
    window.blit(text3s, (200,150))
    window.blit(text4s, (200,200))
    window.blit(text5s, (200,250))
    window.blit(text6s, (200,300))
    window.blit(text7s, (200,350))
    window.blit(text8s, (200,400))
      
    pygame.draw.rect(window,(40, 212, 239),statsDisplayButton)
    window.blit(textStatsDisplay, (statsDisplayButton.x + (statsDisplayButton.width / 4), statsDisplayButton.y + (statsDisplayButton.height / 4)))
    display = True
    while display:
      for event in pygame.event.get():
        if event.type == MOUSEBUTTONDOWN:
          mousePos = pygame.mouse.get_pos()
          #check for click
          if statsDisplayButton.collidepoint(mousePos):
            display = False
          
    
      pygame.display.update()

  def statsClear(self):
    global strength, dexterity, health, intel, wisdom, chrisma, baldness
    strength = 0
    dexterity = 0
    health = 0
    intel = 0
    wisdom = 0
    chrisma = 0
    baldness = 0
        
