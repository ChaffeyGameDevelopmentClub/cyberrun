#Bald Gayte 5
#Galders Bate tree
#B
#Import other files
import sys
import pygame
from pygame.constants import MOUSEBUTTONDOWN
from pygame.locals import QUIT
import random

import statPlacement
import battle
import rooms

#import sys

#import pygame
#from pygame.locals import QUIT

#pygame.init()
#DISPLAYSURF = pygame.display.set_mode((400, 300))
#pygame.display.set_caption('Hello World!')
#while True:
#  for event in pygame.event.get():
#    if event.type == QUIT:
#      pygame.quit()
#      sys.exit()
#  pygame.display.update()




#Define functions
question = statPlacement.Questions()
stat = statPlacement.Stats()
battle = battle.Battle()
room = rooms.Rooms()


#define variables
playerHealth = 1
playerHealth = stat.setMaxHp()
playerAlive = True
show = False

#pygames test
#starts pygame
pygame.init()
#sets the screen size
window = pygame.display.set_mode((1000, 1000))
pygame.display.set_caption('Bald Gate 5')

#define button pos and size
buttonYes = pygame.Rect(200,400,100,50)
buttonNo = pygame.Rect(300,400,100,50)

#set font and text
font = pygame.font.Font('freesansbold.ttf', 32)
text = font.render("Yes", True, (255,255,255))
text2 = font.render("No", True, (255,255,255))
text3 = font.render("You have chosen yes", True, (255,255,255))

#run game
running = True
while running:
  for event in pygame.event.get():
    if event.type == QUIT:
      running = False 


  if playerAlive is True:
    #Ask Questions
    question.Quest1()
    question.Quest2()
    question.Quest3()
    question.Quest4()
    question.Quest5()
    question.Quest6()
    stat.StatsCall()
    stat.StatsCheck()
    stat.statsDisplay()
    

    strength, dexterity, health, intel, wisdom, chrisma, hpMax = stat.StatsCall()
    hp = health*10
    hpMax = hp
    #starting potions
    potions = 3
    
    #room1
    hp = room.Rooms(30,30,8,3,"Physical","Goblindez","Assets/GobSprite.png",1000,300,260,300,strength, dexterity, health, intel, wisdom, chrisma, hpMax,hp)
    #room2
    hp = room.Rooms(100,100,10,10,"Magic","Skeletron","Assets/Skel.png",1000,300,260,300,strength, dexterity, health, intel, wisdom, chrisma, hpMax,hp)
    #room3
    hp = room.Rooms(150,150,15,15,"Lust","SuccuBae","Assets/succ.png",1000,800,280,150,strength, dexterity, health, intel, wisdom, chrisma, hpMax,hp)
    #room4
    hp = room.Rooms(200,200,15,15,"Physical","Ramona Flowers","Assets/roman.png",200,200,700,350,strength, dexterity, health, intel, wisdom, chrisma, hpMax,hp)
    #room5
    hp = room.Rooms(300,300,10,10,"Physical","HobbieDobbie", "Assets/HobGob.png",200,200,700,350,strength, dexterity, health, intel, wisdom, chrisma, hpMax,hp)
    #room6
    hp = room.Rooms(500,500,15,15,"Benny","The Balders Curse", "Assets/benn.png",200,200,700,350,strength, dexterity, health, intel, wisdom, chrisma, hpMax,hp)
    
    print("game done")
  #Ask player to play again
  stat.statsClear()
  
  #update display
  pygame.display.update()

#clean up
pygame.quit()
sys.exit()
 

#testing
#question.Quest1()
#question.Quest2()
#question.Quest3()
#question.Quest4()
#question.Quest5()
#question.Quest6()
#stat.StatsCheck()
#stat.StatsCall()
#set players max hp
#playerHealth = stat.setMaxHp()

#testingRoom1
#battle.Attack()









#Dragons and Dungons
#

