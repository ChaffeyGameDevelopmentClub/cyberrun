import sys
import pygame
from pygame import draw
from pygame.constants import MOUSEBUTTONDOWN
from pygame.locals import QUIT
import random
import battle
import check
import items
import statPlacement

#file for rooms
stats = statPlacement.Stats()
pUpdate = battle.playerUpdate()
fight = battle.Battle()
check1 = check.Check()
dice = items.roll()



pygame.init()
window = pygame.display.set_mode((1000, 1000))
font = pygame.font.Font('freesansbold.ttf', 20)
font2 = pygame.font.Font('freesansbold.ttf', 32)


global hp,hpMax,potions
potions = 0
pAlive = True

def Run(playerHP,enHp,playerDex,playerChr,enName,enAttack,enSpeed):
  #flirt
  pygame.draw.rect(window, (0,0,0), (0,600,1000,1000))
  canRun = False

  #check if canRun
  final = (playerDex+playerChr)/2
  
  check = dice.dice(final)
  if check >= enAttack+enSpeed:
    canRun = True
  if canRun is True:
    textStr = "You sucefully rizzed up the " + enName + " and ran away!"
    text = font.render(textStr, True, (255,255,255))
    window.blit(text, (150,605))
    enHp = 0
    check1.checkContinue()
    damage = playerHP
  elif canRun is False:
    damage = playerHP - enAttack
    textStr = "You failed to rizz up the " + enName + " and couldn't get away away!" + " You lost " + str(enAttack) + " HP!"
    text = font.render(textStr, True, (255,255,255))
    window.blit(text, (150,605))
    check1.checkContinue()
  
  #print("damage: " + str(damage) + " enHp: " + str(enHp))
  return damage, enHp
  #draw continue button



class Rooms:
  def Room1(self):
    #goblinStats
    gobHealth = 30
    gobHealthMax = 30
    gobSpeed = 8
    gobAttack = 3
    gobType = "Physical"

    global hp,hpMax
    global strength, dexterity, health, intel, wisdom, chrisma
    strength, dexterity, health, intel, wisdom, chrisma, hpMax = stats.StatsCall()

    hp = health*10
    hpMax = hp
    potions = 3
    
    while gobHealth > 0:
      #hide anything from before
      pygame.draw.rect(window, (0,0,0), (0,0,1000,1000))
  
      #draw room
      imageBg = pygame.image.load("Assets/BaldGate5Bg.png")
      imageBg = pygame.transform.scale(imageBg, (1000, 800))
      window.blit(imageBg, (0,0))
      #draw player
      imagePlayer = pygame.image.load("Assets/PlayerSprite.png")
      imagePlayer = pygame.transform.scale(imagePlayer, (500, 600))
      window.blit(imagePlayer, (50,75))
      textPlayer = font.render("Mac", True, (0,0,0))
      window.blit(textPlayer, (250,225))
      #draw player hp
      pUpdate.draw_health_bar(window, 25, 25, hp, hpMax)
      pUpdate.draw_Hp_Text(window, 330, 42, hp, hpMax)
      #Draw buttons
      button1 = pygame.Rect(100,600,200,50)
      button2 = pygame.Rect(400,600,200,50)
      button3 = pygame.Rect(700,600,200,50)
      textButton1 = font.render("Attack", True, (255,255,255))
      textButton2 = font.render("Inventory", True, (255,255,255))
      textButton3 = font.render("Flirt", True, (255,255,255))  
      pygame.draw.rect(window,(197, 39, 39),button1)
      pygame.draw.rect(window,(115, 94, 24),button2)
      pygame.draw.rect(window,(208, 87, 214),button3)
      window.blit(textButton1, (170, 615))
      window.blit(textButton2, (455, 615))
      window.blit(textButton3, (785, 615))
      #enemy
      imageEnemy = pygame.image.load("Assets/GobSprite.png")
      imageEnemy = pygame.transform.scale(imageEnemy, (1000, 300))
      window.blit(imageEnemy, (285,280))
      textEnemy = font.render("GoblinDeez", True, (0,0,0))
      window.blit(textEnemy, (735,335))
      #draw enemy hp
      pUpdate.draw_health_bar(window, 675, 25, gobHealth, gobHealthMax)
      pUpdate.draw_Hp_Text(window, 575, 42, gobHealth, gobHealthMax)

      #check for click
      run = True
      while run:
        for event in pygame.event.get():
          if event.type == MOUSEBUTTONDOWN:
            mousePos = pygame.mouse.get_pos()
            #check for click
            if button1.collidepoint(mousePos):
              gobHealth,hp = fight.Attack(hp,strength,intel,chrisma,gobHealth,gobSpeed,gobAttack,gobType)
              #update enemy hp
              pygame.draw.rect(window, (0,0,0), (500, 25, 1000, 50))
              pUpdate.draw_health_bar(window, 675, 25, gobHealth, gobHealthMax)
              pUpdate.draw_Hp_Text(window, 575, 42, gobHealth, gobHealthMax)
              run = False
            if button2.collidepoint(mousePos):
              fight.Inventory(potions,strength,dexterity,health,intel,wisdom,chrisma)
              run = False
            if button3.collidepoint(mousePos):
              hp = fight.Run(hp,dexterity,chrisma,"Goblin",gobAttack,gobSpeed)
              
              #update player hp
              pygame.draw.rect(window, (0,0,0), (0, 25, 500, 50))
              pUpdate.draw_health_bar(window, 25, 25, hp, hpMax)
              pUpdate.draw_Hp_Text(window, 330, 42, hp, hpMax)
              run = False


        pygame.display.update()
    
      pygame.display.update()
  
  def Rooms(self,EHp,EHpMax,ESpeed,EAttack,EType,EName,EImage,Scalex,Scaley,locx,locy, strength, dexterity, health, intel, wisdom, chrisma, hpMax,hp):
    
    
    while EHp > 0:
      #hide anything from before
      pygame.draw.rect(window, (0,0,0), (0,0,1000,1000))

      #draw room
      imageBg = pygame.image.load("Assets/BaldGate5Bg.png")
      imageBg = pygame.transform.scale(imageBg, (1000, 800))
      window.blit(imageBg, (0,0))
      #draw player
      imagePlayer = pygame.image.load("Assets/PlayerSprite.png")
      imagePlayer = pygame.transform.scale(imagePlayer, (500, 600))
      window.blit(imagePlayer, (50,75))
      textPlayer = font.render("Mac", True, (0,0,0))
      window.blit(textPlayer, (250,225))
      #draw player hp
      pUpdate.draw_health_bar(window, 25, 25, hp, hpMax)
      pUpdate.draw_Hp_Text(window, 330, 42, hp, hpMax)
      #Draw buttons
      button1 = pygame.Rect(100,600,200,50)
      button2 = pygame.Rect(400,600,200,50)
      button3 = pygame.Rect(700,600,200,50)
      textButton1 = font.render("Attack", True, (255,255,255))
      textButton2 = font.render("Inventory", True, (255,255,255))
      textButton3 = font.render("Flirt", True, (255,255,255))  
      pygame.draw.rect(window,(197, 39, 39),button1)
      pygame.draw.rect(window,(115, 94, 24),button2)
      pygame.draw.rect(window,(208, 87, 214),button3)
      window.blit(textButton1, (170, 615))
      window.blit(textButton2, (455, 615))
      window.blit(textButton3, (785, 615))
      #enemy
      imageEnemy = pygame.image.load(EImage)
      imageEnemy = pygame.transform.scale(imageEnemy, (Scalex, Scaley))
      window.blit(imageEnemy, (locx,locy))
      textEnemy = font.render(EName, True, (0,0,0))
      window.blit(textEnemy, (735,335))
      #draw enemy hp
      pUpdate.draw_health_bar(window, 675, 25, EHp, EHpMax)
      pUpdate.draw_Hp_Text(window, 575, 42, EHp, EHpMax)
      
      #Check if player is Alive
      #if hp <= 0:
        #call death
        
      #check for click
      run = True
      while run:
        for event in pygame.event.get():
          if event.type == MOUSEBUTTONDOWN:
            mousePos = pygame.mouse.get_pos()
            #check for click
            if button1.collidepoint(mousePos):
              EHp,hp = fight.Attack(hp,strength,intel,chrisma,dexterity,EHp,ESpeed,EAttack,EType)
              #update enemy hp
              pygame.draw.rect(window, (0,0,0), (500, 25, 1000, 50))
              pUpdate.draw_health_bar(window, 675, 25, EHp, EHpMax)
              pUpdate.draw_Hp_Text(window, 575, 42, EHp, EHpMax)
              run = False
            if button2.collidepoint(mousePos):
              fight.Inventory(potions,strength,dexterity,health,intel,wisdom,chrisma)
              run = False
            if button3.collidepoint(mousePos):
              hp,EHp = Run(hp,EHp,dexterity,chrisma,EName,EAttack,ESpeed)

              #update player hp
              pygame.draw.rect(window, (0,0,0), (0, 25, 500, 50))
              pUpdate.draw_health_bar(window, 25, 25, hp, hpMax)
              pUpdate.draw_Hp_Text(window, 330, 42, hp, hpMax)
              run = False


        pygame.display.update()
        if hp <= 0:
          death()
          check1.checkContinue()
          sys.exit()

      pygame.display.update()
      
    return hp    
    
  def Travel(self):
    print("hi")

  def SkillCheck(self):
    print("Hi")

def death():
  #Create a window for death somehow
  pygame.draw.rect(window, (0,0,0), (0,0,1000,1000))
  textStr = "You have died!"
  text = font.render(textStr, True, (255,255,255))
  window.blit(text, (150,605))
  pygame.display.update()
  #pygame.quit()
  #sys.exit()